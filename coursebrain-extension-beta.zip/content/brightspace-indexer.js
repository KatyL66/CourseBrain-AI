"use strict";
(() => {
  // src/shared/content-coverage.ts
  var MAX_FAILED_TITLES = 20;
  function extractViewContentTopicId(url) {
    if (!url) return null;
    const match = url.match(/\/viewContent\/(\d+)/i) || url.match(/\/le\/lessons\/\d+\/topics\/(\d+)/i) || url.match(/\/content\/topics\/(\d+)/i);
    return match?.[1] ?? null;
  }
  function isInCourseContentUrl(url, origin) {
    if (!url) return false;
    try {
      const parsed = new URL(url, origin);
      if (parsed.origin !== new URL(origin).origin) return false;
      const path = parsed.pathname.toLowerCase();
      if (path.includes("/d2l/login") || /\/d2l\/home\/?$/.test(path)) return false;
      return path.includes("/d2l/le/content/") || path.includes("/d2l/le/lessons/") || path.includes("/content/enforced/") || path.includes("/d2l/common/") || path.includes("/d2l/lp/files/");
    } catch {
      return false;
    }
  }
  function isDirectCourseFileUrl(url, origin) {
    if (!isInCourseContentUrl(url, origin)) return false;
    const path = new URL(url, origin).pathname.toLowerCase();
    return !path.includes("/viewcontent/") && !path.includes("/le/lessons/");
  }
  function payloadLooksLikePdf(bytes) {
    return bytes.length >= 5 && bytes[0] === 37 && bytes[1] === 80 && bytes[2] === 68 && bytes[3] === 70;
  }
  function recordFailedTitle(titles, title, cap = MAX_FAILED_TITLES) {
    if (!title || titles.includes(title) || titles.length >= cap) return titles;
    return [...titles, title];
  }
  var MODULE_DESC_MIN_CHARS = 80;
  function moduleDescriptionExternalId(moduleId) {
    return `module-desc:${moduleId}`;
  }
  function moduleDescriptionViewUrl(origin, courseId, moduleId) {
    return `${origin}/d2l/le/content/${courseId}/Home?itemIdentifier=D2L.LE.Content.ContentObject.ModuleCO-${moduleId}`;
  }
  function extractModuleDescriptionHtml(module) {
    const description = module?.Description;
    if (!description) return "";
    if (typeof description === "string") return description.trim();
    return (description.Html || description.Text || "").trim();
  }
  function htmlToPlainText(html) {
    return html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&nbsp;/gi, " ").replace(/\s+/g, " ").trim();
  }
  function isIngestibleModuleDescription(htmlOrText) {
    const text = htmlToPlainText(htmlOrText);
    return text.length >= MODULE_DESC_MIN_CHARS;
  }
  function flattenContentToc(toc) {
    const modules = Array.isArray(toc) ? toc : toc?.Modules ?? [];
    const out = [];
    const walk = (mods, prefix) => {
      for (const mod of mods) {
        if (mod.IsHidden) continue;
        const title = (mod.Title || "").trim() || "Module";
        const path = prefix ? `${prefix} > ${title}` : title;
        for (const topic of mod.Topics || []) {
          if (topic.IsHidden) continue;
          const id = topic.TopicId ?? topic.Id;
          if (id == null) continue;
          out.push({
            topicId: String(id),
            title: (topic.Title || "").trim() || `Topic ${id}`,
            modulePath: path,
            url: topic.Url,
            topicType: topic.TopicType,
            typeIdentifier: topic.TypeIdentifier
          });
        }
        if (mod.Modules?.length) walk(mod.Modules, path);
      }
    };
    walk(modules, "");
    return out;
  }

  // src/shared/dropbox.ts
  var SEARCHABLE_ATTACHMENT_EXT = [".pdf", ".html", ".htm", ".txt"];
  function isSearchableAttachment(filename) {
    const lower = filename.toLowerCase();
    return SEARCHABLE_ATTACHMENT_EXT.some((ext) => lower.endsWith(ext));
  }
  function dropboxFolderUrl(origin, orgUnitId, folderId) {
    const base = origin.replace(/\/$/, "");
    return `${base}/d2l/lms/dropbox/user/folder_submit_files.d2l?db=${encodeURIComponent(folderId)}&ou=${encodeURIComponent(orgUnitId)}`;
  }
  function dueAtFromFolder(folder) {
    return folder.DueDate || null;
  }
  function submissionTypeLabel(value) {
    if (value == null || value === "") return void 0;
    const map = {
      "0": "File",
      "1": "Text",
      "2": "OnPaper",
      "3": "Observed",
      "4": "File or Text",
      File: "File",
      Text: "Text",
      OnPaper: "OnPaper",
      Observed: "Observed"
    };
    const key = String(value);
    return map[key] ?? key;
  }
  function richTextToHtml(value) {
    if (!value) return "";
    if (typeof value === "string") return value;
    if (typeof value === "object") {
      const rec = value;
      return rec.Html || rec.Text || "";
    }
    return "";
  }

  // src/shared/copy.ts
  var zh = {
    apiOnline: "API \u5728\u7EBF",
    apiOffline: "API \u79BB\u7EBF",
    inviteSaved: "\u9080\u8BF7\u7801\u5DF2\u4FDD\u5B58\u5728\u8FD9\u53F0\u6D4F\u89C8\u5668\u3002",
    changeInvite: "\u66F4\u6362",
    invitePrompt: "\u8F93\u5165 CourseBrain \u9080\u8BF7\u7801\u540E\u5373\u53EF\u540C\u6B65\u548C\u63D0\u95EE\u3002\u4E0D\u9700\u8981\u586B\u5199 OpenAI Key\u3002",
    invitePlaceholder: "\u9080\u8BF7\u7801",
    saveInvite: "\u4FDD\u5B58\u9080\u8BF7\u7801",
    myCourses: "\u6211\u7684\u8BFE\u7A0B",
    noCourses: "\u8FD8\u6CA1\u6709\u540C\u6B65\u8FC7\u7684\u8BFE\u7A0B",
    currentPage: "\u5F53\u524D\u9875",
    asking: "\u63D0\u95EE\u4E2D",
    filesAndChunks: (files, chunks) => `${files} \u6587\u4EF6 \xB7 ${chunks} \u6BB5`,
    askingCourse: (name) => `\u63D0\u95EE\uFF1A${name}`,
    askingOtherPage: (name) => `\u63D0\u95EE\uFF1A${name}\uFF08\u4E0D\u662F\u5F53\u524D Brightspace \u9875\u9762\uFF09`,
    courseNotSynced: "\u5F53\u524D\u8BFE\u7A0B\u5C1A\u672A\u540C\u6B65",
    pickCourse: "\u8BF7\u5148\u540C\u6B65\u6216\u9009\u62E9\u4E00\u95E8\u8BFE",
    unsyncedBanner: "\u5F53\u524D Brightspace \u8BFE\u7A0B\u5C1A\u672A\u540C\u6B65\u5230 CourseBrain\u3002\u8BF7\u540C\u6B65\u5F53\u524D\u8BFE\u7A0B\uFF0C\u6216\u624B\u52A8\u9009\u62E9\u4E00\u95E8\u5DF2\u540C\u6B65\u8BFE\u7A0B\u63D0\u95EE\u3002",
    syncCourse: "\u540C\u6B65\u5F53\u524D Brightspace \u8BFE\u7A0B",
    askPlaceholder: "\u4F8B\u5982\uFF1Agroup project \u7684\u8981\u6C42\u662F\u4EC0\u4E48\uFF1F",
    askNeedCourse: "\u8BF7\u5148\u540C\u6B65\u5F53\u524D\u8BFE\u7A0B\uFF0C\u6216\u9009\u62E9\u4E00\u95E8\u5DF2\u540C\u6B65\u8BFE\u7A0B",
    searching: "\u641C\u7D22\u4E2D...",
    ask: "\u63D0\u95EE",
    answer: "\u56DE\u7B54",
    sources: "\u8BFE\u7A0B\u4F9D\u636E",
    sourcesHint: "\u672C\u56DE\u7B54\u5F15\u7528\u7684\u8BFE\u7A0B\u6750\u6599\uFF0C\u70B9\u51FB\u53EF\u6253\u5F00 Brightspace \u539F\u6587\u3002",
    hideRetrieved: "\u9690\u85CF",
    showRetrieved: "\u67E5\u770B",
    retrievedToggle: (shown, n) => `${shown ? "\u9690\u85CF" : "\u67E5\u770B"}\u68C0\u7D22\u4E0A\u4E0B\u6587\uFF08${n}\uFF09`,
    retrievedHint: (n) => `\u8C03\u8BD5\u4FE1\u606F\uFF1A\u53D1\u7ED9\u6A21\u578B\u7684 Top ${n} \u68C0\u7D22\u7247\u6BB5\uFF08\u672A\u5FC5\u5168\u90E8\u88AB\u5F15\u7528\uFF09\u3002`,
    footer: "\u5207\u6362\u8BFE\u7A0B\u540E\u63D0\u95EE\u4F1A\u9488\u5BF9\u6240\u9009\u8BFE\u7A0B\uFF1B\u5728\u8BFE\u7A0B\u9875\u6253\u5F00\u4F1A\u81EA\u52A8\u9009\u4E2D\u8BE5\u8BFE",
    unknownSource: "\u672A\u77E5\u6765\u6E90",
    pageLabel: (page) => `\u7B2C ${page} \u9875`,
    relevance: (score) => `\u76F8\u5173\u5EA6 ${score}`,
    openLocate: "\u6253\u5F00\u5E76\u5B9A\u4F4D",
    openLabel: (label) => `\u6253\u5F00 ${label}`,
    startSync: "\u5F00\u59CB\u540C\u6B65...",
    syncFailed: "\u540C\u6B65\u5931\u8D25",
    indexFailed: "\u7D22\u5F15\u5931\u8D25",
    openBrightspace: "\u8BF7\u5148\u6253\u5F00 Brightspace \u8BFE\u7A0B\u9875\u9762",
    uploading: "\u4E0A\u4F20\u5230 CourseBrain \u540E\u7AEF...",
    pageScriptMissing: "\u65E0\u6CD5\u8FDE\u63A5\u9875\u9762\u811A\u672C\u3002\u8BF7\u5237\u65B0 Brightspace \u9875\u9762\u540E\u91CD\u8BD5\u3002",
    courseUnrecognized: "\u65E0\u6CD5\u8BC6\u522B\u5F53\u524D\u8BFE\u7A0B\uFF0C\u8BF7\u6253\u5F00\u4E00\u95E8 Brightspace \u8BFE\u7A0B\u540E\u518D\u540C\u6B65",
    fetchingCatalog: "\u83B7\u53D6\u8BFE\u7A0B\u76EE\u5F55...",
    foundTopics: (n) => `\u53D1\u73B0 ${n} \u4E2A\u5B66\u4E60\u8D44\u6E90\uFF0C\u5F00\u59CB\u62C9\u53D6...`,
    fetchedProgress: (current, total) => `\u5DF2\u62C9\u53D6 ${current}/${total}`,
    fetchingAssignments: "\u83B7\u53D6 Brightspace Assignments...",
    fetchingTopic: (title) => `\u62C9\u53D6: ${title}`,
    fetchingAssignment: (name) => `\u4F5C\u4E1A: ${name}`,
    foundResources: (resources, pdfs, skippedNav) => `\u53D1\u73B0 ${resources} \u4E2A\u8D44\u6E90\uFF08PDF ${pdfs}\uFF09\uFF0C\u8DF3\u8FC7\u5BFC\u822A ${skippedNav}`,
    assignmentsSuffix: (n) => `\uFF0C${n} \u4E2A\u4F5C\u4E1A`,
    syncDone: (files, assignmentSuffix, chunks) => `\u5B8C\u6210\uFF1A\u7D22\u5F15 ${files} \u4E2A\u6587\u4EF6${assignmentSuffix}\uFF0C${chunks} \u6BB5\u53EF\u641C\u7D22`,
    syncedCourse: "\u5DF2\u540C\u6B65\u8BFE\u7A0B",
    timeout: "\u8BF7\u6C42\u8D85\u65F6\u3002\u540C\u6B65\u8D44\u6599\u5F88\u591A\u7684\u8BFE\u7A0B\u53EF\u80FD\u9700\u8981\u51E0\u5206\u949F\uFF0C\u8BF7\u518D\u8BD5\u4E00\u6B21\u3002",
    unauthorized: "\u9080\u8BF7\u7801\u65E0\u6548\u3002\u8BF7\u5411 CourseBrain \u7D22\u53D6\u65B0\u7684\u9080\u8BF7\u7801\u540E\u518D\u8BD5\u3002",
    questionLimit: "\u4ECA\u5929\u7684\u63D0\u95EE\u6B21\u6570\u5DF2\u7528\u5B8C\uFF0C\u660E\u5929\u4F1A\u6062\u590D\u3002",
    syncLimit: "\u4ECA\u5929\u7684\u540C\u6B65\u6B21\u6570\u5DF2\u7528\u5B8C\uFF0C\u660E\u5929\u4F1A\u6062\u590D\u3002",
    serverError: "CourseBrain \u6682\u65F6\u65E0\u6CD5\u5B8C\u6210\u8FD9\u4E2A\u8BF7\u6C42\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    network: "\u65E0\u6CD5\u8FDE\u63A5 CourseBrain\u3002\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002",
    workerSilent: "Service worker \u65E0\u54CD\u5E94 \u2014 \u8BF7\u5728 chrome://extensions \u5237\u65B0 CourseBrain \u540E\u91CD\u8BD5",
    workerSilentShort: "Service worker \u65E0\u54CD\u5E94 \u2014 \u8BF7\u5237\u65B0\u63D2\u4EF6\u540E\u91CD\u8BD5"
  };
  var en = {
    apiOnline: "API online",
    apiOffline: "API offline",
    inviteSaved: "Invite code is saved in this browser.",
    changeInvite: "Change",
    invitePrompt: "Enter your CourseBrain invite code to sync and ask questions. An OpenAI key is not required.",
    invitePlaceholder: "Invite code",
    saveInvite: "Save invite code",
    myCourses: "My courses",
    noCourses: "No courses synced yet",
    currentPage: "This page",
    asking: "Asking",
    filesAndChunks: (files, chunks) => `${files} files \xB7 ${chunks} sections`,
    askingCourse: (name) => `Asking: ${name}`,
    askingOtherPage: (name) => `Asking: ${name} (not the current Brightspace page)`,
    courseNotSynced: "This course is not synced yet",
    pickCourse: "Sync or choose a course first",
    unsyncedBanner: "This Brightspace course is not in CourseBrain yet. Sync it, or choose a course you already synced.",
    syncCourse: "Sync this Brightspace course",
    askPlaceholder: "For example: What are the group project requirements?",
    askNeedCourse: "Sync this course, or choose a synced course",
    searching: "Searching...",
    ask: "Ask",
    answer: "Answer",
    sources: "Course sources",
    sourcesHint: "Materials cited in this answer. Click one to open it in Brightspace.",
    hideRetrieved: "Hide",
    showRetrieved: "Show",
    retrievedToggle: (shown, n) => `${shown ? "Hide" : "Show"} retrieved context (${n})`,
    retrievedHint: (n) => `Debug: top ${n} passages sent to the model. Not all of them are cited.`,
    footer: "Questions use the selected course. Opening a course page selects that course.",
    unknownSource: "Unknown source",
    pageLabel: (page) => `p. ${page}`,
    relevance: (score) => `Relevance ${score}`,
    openLocate: "Open and locate",
    openLabel: (label) => `Open ${label}`,
    startSync: "Starting sync...",
    syncFailed: "Sync failed",
    indexFailed: "Indexing failed",
    openBrightspace: "Open a Brightspace course page first.",
    uploading: "Uploading to CourseBrain...",
    pageScriptMissing: "Can't reach the page script. Refresh the Brightspace page and try again.",
    courseUnrecognized: "Can't tell which course this is. Open a Brightspace course, then sync.",
    fetchingCatalog: "Reading the course contents...",
    foundTopics: (n) => `Found ${n} items. Fetching them...`,
    fetchedProgress: (current, total) => `Fetched ${current}/${total}`,
    fetchingAssignments: "Fetching Brightspace assignments...",
    fetchingTopic: (title) => `Fetching: ${title}`,
    fetchingAssignment: (name) => `Assignment: ${name}`,
    foundResources: (resources, pdfs, skippedNav) => `Found ${resources} resources (PDF ${pdfs}), skipped navigation ${skippedNav}`,
    assignmentsSuffix: (n) => `, ${n} assignments`,
    syncDone: (files, assignmentSuffix, chunks) => `Done: indexed ${files} files${assignmentSuffix}, ${chunks} searchable sections`,
    syncedCourse: "Synced course",
    timeout: "The request timed out. A large course can take a few minutes to sync. Try again.",
    unauthorized: "That invite code is not valid. Ask the CourseBrain maintainer for a new one.",
    questionLimit: "You've used today's question limit. It resets tomorrow.",
    syncLimit: "You've used today's sync limit. It resets tomorrow.",
    serverError: "CourseBrain couldn't finish that request. Try again in a moment.",
    network: "Can't reach CourseBrain. Check your connection and try again.",
    workerSilent: "Service worker did not respond. Refresh CourseBrain at chrome://extensions and try again.",
    workerSilentShort: "Service worker did not respond. Refresh the extension and try again."
  };
  var BY_LOCALE = { en, zh };
  function copyFor(locale) {
    return BY_LOCALE[locale];
  }

  // src/shared/locale.ts
  var LOCALE_KEY = "uiLocale";
  function isLocale(value) {
    return value === "en" || value === "zh";
  }
  function getLocale() {
    return new Promise((resolve) => {
      chrome.storage.local.get([LOCALE_KEY], (data) => {
        const value = data[LOCALE_KEY];
        resolve(isLocale(value) ? value : null);
      });
    });
  }

  // src/shared/types.ts
  function firstQueryOu(url) {
    for (const key of ["ou", "OU", "orgUnitId", "OrgUnitId"]) {
      const value = url.searchParams.get(key);
      if (value && /^\d{4,}$/.test(value)) return value;
    }
    return null;
  }
  function extractExternalIdFromUrl(url) {
    try {
      const parsed = new URL(url);
      const fromQuery = firstQueryOu(parsed);
      if (fromQuery) return fromQuery;
      const pathMatch = parsed.pathname.match(/\/(\d{4,})(?:\/|$)/);
      return pathMatch?.[1] ?? null;
    } catch {
      const match = url.match(/\/(\d{4,})(?:\/|$|\?)/);
      return match?.[1] ?? null;
    }
  }

  // src/content/brightspace-indexer.ts
  var API_VER = "1.82";
  var CONTENT_TYPE_MODULE = 0;
  var CONTENT_TYPE_TOPIC = 1;
  var TOPIC_TYPE_FILE = 1;
  var TOPIC_TYPE_LINK = 3;
  function extractCourseId() {
    const fromUrl = extractExternalIdFromUrl(location.href);
    if (fromUrl) return fromUrl;
    const hidden = document.querySelector('input[name="ou"]');
    if (hidden?.value && /^\d{4,}$/.test(hidden.value)) return hidden.value;
    return null;
  }
  function absoluteUrl(path) {
    if (path.startsWith("http")) return path;
    return `${location.origin}${path.startsWith("/") ? "" : "/"}${path}`;
  }
  function topicViewUrl(courseId, topicId) {
    return `${location.origin}/d2l/le/content/${courseId}/viewContent/${topicId}/View`;
  }
  function fileKindFromUrl(url) {
    const lower = (url || "").toLowerCase();
    if (lower.endsWith(".html") || lower.endsWith(".htm")) return "html";
    return "pdf";
  }
  function fileExt(filename) {
    const match = filename.toLowerCase().match(/\.([a-z0-9]+)$/);
    return match?.[1] ?? "";
  }
  function isNavigationHtml(html) {
    const markers = [
      "Table of Contents -",
      "d2l-navigation",
      "Notifications Account Settings",
      "Are You Still There?"
    ];
    let hits = 0;
    for (const m of markers) {
      if (html.includes(m)) hits++;
    }
    return hits >= 2;
  }
  async function apiGet(path) {
    const res = await fetch(path, { credentials: "include" });
    if (!res.ok) throw new Error(`API ${path} failed: ${res.status}`);
    return res.json();
  }
  function logDiscovery(message) {
    console.log(`[CourseBrain] ${message}`);
  }
  function moduleTitleFromPath(modulePath) {
    const parts = modulePath.split(">").map((part) => part.trim()).filter(Boolean);
    return parts[parts.length - 1] || modulePath;
  }
  async function ingestModuleDescription(courseId, moduleId, modulePath, out, seenTopicIds, summary, embedded) {
    const topicId = moduleDescriptionExternalId(moduleId);
    if (seenTopicIds.has(topicId)) return;
    let html = extractModuleDescriptionHtml(embedded);
    if (!isIngestibleModuleDescription(html)) {
      try {
        const details = await apiGet(
          `/d2l/api/le/${API_VER}/${courseId}/content/modules/${moduleId}`
        );
        html = extractModuleDescriptionHtml(details);
      } catch (e) {
        logDiscovery(`  ${modulePath} [module description] fetch failed: ${String(e)}`);
        return;
      }
    }
    if (!isIngestibleModuleDescription(html)) {
      logDiscovery(`  ${modulePath} [module description] \u2192 SKIP empty`);
      return;
    }
    seenTopicIds.add(topicId);
    summary.resourcesDiscovered++;
    summary.htmlContent++;
    logDiscovery(`  ${modulePath} [module description] \u2192 INGEST`);
    out.push({
      external_id: topicId,
      module_name: modulePath,
      title: moduleTitleFromPath(modulePath),
      url: moduleDescriptionViewUrl(location.origin, courseId, moduleId),
      file_type: "html",
      content: html
    });
  }
  async function discoverModuleStructure(courseId, moduleId, modulePath, out, seenTopicIds, summary, embedded) {
    summary.modulesDiscovered++;
    await ingestModuleDescription(
      courseId,
      moduleId,
      modulePath,
      out,
      seenTopicIds,
      summary,
      embedded
    );
    let items = [];
    try {
      const structure = await apiGet(
        `/d2l/api/le/${API_VER}/${courseId}/content/modules/${moduleId}/structure/`
      );
      items = Array.isArray(structure) ? structure : [structure];
    } catch (e) {
      logDiscovery(`MODULE structure failed for ${modulePath}: ${String(e)}`);
      return;
    }
    logDiscovery(`MODULE: ${modulePath}`);
    for (const item of items) {
      if (item.Type === CONTENT_TYPE_MODULE) {
        summary.containersSkipped++;
        const childPath = `${modulePath} > ${item.Title}`;
        logDiscovery(`  ${item.Title} [module container] \u2192 recurse`);
        await discoverModuleStructure(
          courseId,
          item.Id,
          childPath,
          out,
          seenTopicIds,
          summary,
          item
        );
        continue;
      }
      if (item.Type !== CONTENT_TYPE_TOPIC) {
        logDiscovery(`  ${item.Title} [type ${item.Type}] \u2192 SKIP`);
        continue;
      }
      enqueueContentTopic(courseId, item, modulePath, out, seenTopicIds, summary);
    }
  }
  function enqueueContentTopic(courseId, item, modulePath, out, seenTopicIds, summary, source = "") {
    const topicId = String(item.Id);
    const label = source ? `${source} ` : "";
    if (seenTopicIds.has(topicId)) {
      summary.duplicatesSkipped++;
      logDiscovery(`  ${item.Title} [duplicate id=${topicId}] \u2192 SKIP`);
      return;
    }
    if (item.TopicType === TOPIC_TYPE_LINK) {
      const url = item.Url ? absoluteUrl(item.Url) : topicViewUrl(courseId, topicId);
      if (!isInCourseContentUrl(url, location.origin)) {
        summary.linksSkipped++;
        logDiscovery(`  ${item.Title} [external link] ${url} \u2192 SKIP`);
        return;
      }
      const fileType = fileKindFromUrl(url);
      seenTopicIds.add(topicId);
      summary.resourcesDiscovered++;
      if (fileType === "pdf") summary.pdfs++;
      else summary.htmlContent++;
      logDiscovery(`  ${item.Title} [${label}in-course link] \u2192 INGEST`);
      out.push({
        external_id: topicId,
        module_name: modulePath,
        title: item.Title,
        url,
        topic_type: item.TopicType,
        file_type: fileType
      });
      return;
    }
    if (item.TopicType === TOPIC_TYPE_FILE) {
      const fileType = fileKindFromUrl(item.Url);
      seenTopicIds.add(topicId);
      summary.resourcesDiscovered++;
      if (fileType === "pdf") summary.pdfs++;
      else summary.htmlContent++;
      logDiscovery(`  ${item.Title} [${label}${fileType.toUpperCase()}] \u2192 INGEST`);
      out.push({
        external_id: topicId,
        module_name: modulePath,
        title: item.Title,
        url: item.Url ? absoluteUrl(item.Url) : topicViewUrl(courseId, topicId),
        topic_type: item.TopicType,
        file_type: fileType
      });
      return;
    }
    seenTopicIds.add(topicId);
    summary.resourcesDiscovered++;
    summary.htmlContent++;
    logDiscovery(`  ${item.Title} [${label}html topic type=${item.TopicType ?? "?"}] \u2192 INGEST`);
    out.push({
      external_id: topicId,
      module_name: modulePath,
      title: item.Title,
      url: item.Url ? absoluteUrl(item.Url) : topicViewUrl(courseId, topicId),
      topic_type: item.TopicType,
      file_type: "html"
    });
  }
  async function discoverFromToc(courseId, out, seenTopicIds, summary) {
    let toc;
    try {
      toc = await apiGet(
        `/d2l/api/le/${API_VER}/${courseId}/content/toc?ignoreDates=true`
      );
    } catch (e) {
      logDiscovery(`TOC fetch failed: ${String(e)}`);
      return;
    }
    const listed = flattenContentToc(toc);
    logDiscovery(`TOC listed ${listed.length} student-visible topics`);
    let added = 0;
    for (const item of listed) {
      if (seenTopicIds.has(item.topicId)) continue;
      enqueueContentTopic(
        courseId,
        {
          Id: Number(item.topicId),
          Title: item.title,
          Type: CONTENT_TYPE_TOPIC,
          TopicType: item.topicType,
          Url: item.url
        },
        item.modulePath,
        out,
        seenTopicIds,
        summary,
        "toc"
      );
      if (seenTopicIds.has(item.topicId)) added++;
    }
    logDiscovery(`TOC added ${added} topics missed by module walk`);
  }
  function topicFileApiPath(courseId, topicId) {
    return `/d2l/api/le/${API_VER}/${courseId}/content/topics/${topicId}/file`;
  }
  function candidateFetchUrls(courseId, topic) {
    const urls = [];
    const add = (url) => {
      if (!url || urls.includes(url)) return;
      urls.push(url);
    };
    add(topicFileApiPath(courseId, topic.external_id));
    const linkedId = extractViewContentTopicId(topic.url);
    if (linkedId && linkedId !== topic.external_id) {
      add(topicFileApiPath(courseId, linkedId));
    }
    if (topic.url && isDirectCourseFileUrl(topic.url, location.origin)) {
      add(topic.url);
    }
    return urls;
  }
  function recordFailedFetch(summary, title) {
    summary.failedFetch++;
    summary.failedTitles = recordFailedTitle(summary.failedTitles, title);
  }
  async function materializeFetchedResponse(res, topic) {
    const buffer = await res.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    if (payloadLooksLikePdf(bytes)) {
      topic.content_base64 = bytesToBase64(buffer);
      topic.file_type = "pdf";
      return topic;
    }
    const text = new TextDecoder("utf-8").decode(bytes);
    const contentType = (res.headers.get("content-type") || "").toLowerCase();
    const looksHtml = contentType.includes("html") || text.trimStart().startsWith("<");
    if (looksHtml) {
      if (isNavigationHtml(text)) return "nav";
      topic.content = text;
      topic.file_type = "html";
      return topic;
    }
    topic.content_base64 = bytesToBase64(buffer);
    topic.file_type = "pdf";
    return topic;
  }
  async function fetchTopicContent(courseId, topic, summary, text, onProgress) {
    onProgress?.(text.fetchingTopic(topic.title));
    if (topic.content || topic.content_base64) {
      return topic;
    }
    const urls = candidateFetchUrls(courseId, topic);
    let sawNavigation = false;
    for (const url of urls) {
      try {
        const res = await fetch(url, { credentials: "include" });
        if (!res.ok) {
          logDiscovery(`  ${topic.title} [${url}] \u2192 ${res.status}, retry`);
          continue;
        }
        const filled = await materializeFetchedResponse(res, topic);
        if (filled === "nav") {
          sawNavigation = true;
          logDiscovery(`  ${topic.title} [${url}] [navigation HTML] \u2192 retry`);
          continue;
        }
        if (filled?.content || filled?.content_base64) return filled;
      } catch (e) {
        logDiscovery(`  ${topic.title} [${url}] error: ${String(e)}`);
      }
    }
    if (sawNavigation) {
      summary.navigationSkipped++;
      logDiscovery(`  ${topic.title} [navigation HTML] \u2192 SKIP after fetch`);
      return null;
    }
    recordFailedFetch(summary, topic.title);
    logDiscovery(`  ${topic.title} [unsupported or fetch failed] \u2192 SKIP`);
    return null;
  }
  function bytesToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  }
  async function fetchDropboxFolders(courseId) {
    const res = await fetch(`/d2l/api/le/${API_VER}/${courseId}/dropbox/folders/`, {
      credentials: "include"
    });
    if (res.status === 403 || res.status === 404) {
      logDiscovery(`Assignments API ${res.status} \u2014 skipping dropbox`);
      return [];
    }
    if (!res.ok) throw new Error(`Dropbox folders failed: ${res.status}`);
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  }
  async function fetchAssignmentAttachment(courseId, folderId, fileId, filename) {
    const res = await fetch(
      `/d2l/api/le/${API_VER}/${courseId}/dropbox/folders/${folderId}/attachments/${fileId}`,
      { credentials: "include" }
    );
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type") || "";
    const lower = filename.toLowerCase();
    const asHtml = contentType.includes("html") || lower.endsWith(".html") || lower.endsWith(".htm");
    if (asHtml) {
      return { filename, file_type: "html", content: await res.text() };
    }
    return {
      filename,
      file_type: "pdf",
      content_base64: bytesToBase64(await res.arrayBuffer())
    };
  }
  async function ingestDropboxAssignments(courseId, summary, text, onProgress) {
    let folders = [];
    try {
      folders = await fetchDropboxFolders(courseId);
    } catch (e) {
      logDiscovery(`Assignments fetch failed: ${String(e)}`);
      return [];
    }
    const out = [];
    for (const folder of folders) {
      if (folder.IsHidden) continue;
      summary.assignmentsDiscovered++;
      onProgress?.(text.fetchingAssignment(folder.Name));
      const attachments = [];
      for (const file of folder.Attachments || []) {
        if (!isSearchableAttachment(file.FileName)) {
          attachments.push({ filename: file.FileName, file_type: fileExt(file.FileName) });
          continue;
        }
        try {
          const att = await fetchAssignmentAttachment(
            courseId,
            folder.Id,
            file.FileId,
            file.FileName
          );
          if (att) attachments.push(att);
          else attachments.push({ filename: file.FileName, file_type: fileExt(file.FileName) });
        } catch {
          recordFailedFetch(summary, file.FileName || folder.Name);
          attachments.push({ filename: file.FileName, file_type: fileExt(file.FileName) });
        }
      }
      out.push({
        object_id: String(folder.Id),
        name: folder.Name,
        canonical_url: dropboxFolderUrl(location.origin, courseId, String(folder.Id)),
        due_at: dueAtFromFolder(folder),
        submission_type: submissionTypeLabel(folder.SubmissionType),
        instructions: richTextToHtml(folder.CustomInstructions) || void 0,
        attachments
      });
    }
    logDiscovery(`Assignments discovered: ${summary.assignmentsDiscovered}`);
    return out;
  }
  async function runBrightspaceIndex(onProgress) {
    const text = copyFor(await getLocale() ?? "zh");
    const courseId = extractCourseId();
    if (!courseId) {
      throw new Error(text.courseUnrecognized);
    }
    onProgress({ phase: "discover", current: 0, total: 0, message: text.fetchingCatalog });
    const rootModules = await apiGet(
      `/d2l/api/le/${API_VER}/${courseId}/content/root/`
    );
    const courseName = document.querySelector(".d2l-navigation-s-title")?.textContent?.trim() || document.title || `Course ${courseId}`;
    const topics = [];
    const seenTopicIds = /* @__PURE__ */ new Set();
    const summary = {
      modulesDiscovered: 0,
      resourcesDiscovered: 0,
      pdfs: 0,
      htmlContent: 0,
      linksSkipped: 0,
      containersSkipped: 0,
      navigationSkipped: 0,
      duplicatesSkipped: 0,
      indexed: 0,
      failedFetch: 0,
      failedTitles: [],
      assignmentsDiscovered: 0
    };
    logDiscovery("=== Discovery start ===");
    for (const item of rootModules) {
      if (item.Type === CONTENT_TYPE_TOPIC) {
        enqueueContentTopic(courseId, item, item.Title || "Root", topics, seenTopicIds, summary, "root");
        continue;
      }
      await discoverModuleStructure(
        courseId,
        item.Id,
        item.Title,
        topics,
        seenTopicIds,
        summary,
        item
      );
    }
    await discoverFromToc(courseId, topics, seenTopicIds, summary);
    logDiscovery(
      `Discovered ${summary.resourcesDiscovered} resources (PDF ${summary.pdfs}, HTML ${summary.htmlContent}, containers skipped ${summary.containersSkipped}, links skipped ${summary.linksSkipped})`
    );
    onProgress({
      phase: "fetch",
      current: 0,
      total: topics.length,
      message: text.foundTopics(topics.length)
    });
    const enriched = [];
    for (let i = 0; i < topics.length; i++) {
      const topic = topics[i];
      try {
        const filled = await fetchTopicContent(
          courseId,
          { ...topic },
          summary,
          text,
          (msg) => onProgress({
            phase: "fetch",
            current: i + 1,
            total: topics.length,
            message: msg
          })
        );
        if (filled?.content || filled?.content_base64) {
          enriched.push(filled);
          summary.indexed++;
        }
      } catch (e) {
        recordFailedFetch(summary, topic.title);
        console.warn("[CourseBrain] skip topic:", topic.title, e);
      }
      onProgress({
        phase: "fetch",
        current: i + 1,
        total: topics.length,
        message: text.fetchedProgress(i + 1, topics.length)
      });
    }
    onProgress({
      phase: "fetch",
      current: topics.length,
      total: topics.length,
      message: text.fetchingAssignments
    });
    const assignments = await ingestDropboxAssignments(
      courseId,
      summary,
      text,
      (msg) => onProgress({
        phase: "fetch",
        current: topics.length,
        total: topics.length,
        message: msg
      })
    );
    logDiscovery("=== Discovery summary ===");
    logDiscovery(`Resources discovered: ${summary.resourcesDiscovered}`);
    logDiscovery(`Successfully fetched: ${summary.indexed}`);
    logDiscovery(`Assignments: ${summary.assignmentsDiscovered}`);
    logDiscovery(`PDF: ${summary.pdfs}`);
    logDiscovery(`HTML content: ${summary.htmlContent}`);
    logDiscovery(`Containers skipped: ${summary.containersSkipped}`);
    logDiscovery(`Navigation skipped: ${summary.navigationSkipped}`);
    logDiscovery(`Links skipped: ${summary.linksSkipped}`);
    logDiscovery(`Duplicates skipped: ${summary.duplicatesSkipped}`);
    logDiscovery(`Failed fetch: ${summary.failedFetch}`);
    if (summary.failedTitles.length) {
      logDiscovery(`Failed titles: ${summary.failedTitles.join(", ")}`);
    }
    return {
      external_id: courseId,
      name: courseName,
      topics: enriched,
      assignments,
      summary
    };
  }
  if (!globalThis.__courseBrainIndexer) {
    globalThis.__courseBrainIndexer = true;
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg.type === "RUN_INDEX") {
        runBrightspaceIndex((progress) => {
          chrome.runtime.sendMessage({ type: "SYNC_PROGRESS", payload: progress }).catch(() => {
          });
        }).then((result) => sendResponse({ ok: true, result })).catch(
          (err) => sendResponse({
            ok: false,
            error: err instanceof Error ? err.message : String(err)
          })
        );
        return true;
      }
    });
  }
})();
